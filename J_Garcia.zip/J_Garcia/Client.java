import java.net.*;
import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import java.io.*;

public class Client{
    private Socket socket; // socket used to connect to server
    private DataOutputStream output; // output stream

    // constructor to put values in variables, will use later
    public Client() {
        this.socket = null;
        //this.input = null;
        this.output = null;
    }

    /**
     * 
     * @param address
     * @param port 
     * address and port used to get connection to the server.
     */
    public void accessServer(String address, int port, String logName) {
        Scanner scan = new Scanner(System.in);
        Logger log = Logger.getLogger(logName); // logs the log
        FileHandler fh;
        try {
            fh = new FileHandler("C:/J_Garcia/logFile.log", true); // creates or appends to created file
            File file = new File("C:/J_Garcia/logFile.log.lck"); // a file was created that would make the program crash if tried to run again. I have to delete the created file every time.
            log.addHandler(fh);
            SimpleFormatter format = new SimpleFormatter(); // to format the log
            fh.setFormatter(format); // used to format log
            socket = new Socket(address, port); 
            System.out.println("Connected"); // shows connection to port
            log.info("Successfully Connected. IP: " + address + " Port: " + port); // log connection to server
            file.delete(); // delete added file here
            output = new DataOutputStream(socket.getOutputStream()); // gets output stream of socket to write to server
            String clientMessage = "", serverMessage = "";
            BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedReader kb = new BufferedReader(new InputStreamReader(System.in));
    
            while (!(clientMessage = kb.readLine()).equals("exit")) {

                output.writeBytes(clientMessage + "\n");
                log.info("Sending message to Server."); // logging information
                log.info("Message sent: " + clientMessage);
                log.info("Waiting for response from server... ");
                serverMessage = br.readLine(); //reading server message
                log.info("recieved message from server.");
                log.info("server reply: " + serverMessage);
                System.out.println(serverMessage);
            }
            kb.close();
            br.close();
        } catch (UnknownHostException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        } catch (SecurityException e) {
            System.out.println(e.getMessage());
        }

        

        try {
            output.close(); // close sockets and output messenger
            socket.close();
            scan.close();
        } catch(IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public Socket getSocket() {
        return this.socket;
    }

    public void setSocket(String address, int port) throws IOException {
        this.socket = new Socket(address, port);
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Client client = new Client();
        String line = scan.nextLine();
        String[] parse = line.split(" ");
        String IP = parse[1];
        int port = Integer.parseInt(parse[3]);
        String log = parse[5];
        System.out.println("connecting");
        client.accessServer(IP, port, log);
        scan.close();
    }
}